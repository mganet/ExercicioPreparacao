package Exercicios;

import java.util.Random;
import java.util.Scanner;

public class Exercicio8 {

    public Exercicio8() {
    
        Random rand = new Random();
        
        int numAleatorio = rand.nextInt(20),
            numEscolhido = 0,
            pontuacao    = 0;
        
        String tecla     = " ";
        
        boolean game     = true;
        
        while(game == true) {
           
        System.out.println("Número: " + numAleatorio);
        System.out.print("Proximo número é acima(c) ou a baixo(b): ");
        tecla = new Scanner(System.in).nextLine();
        
        numEscolhido = numAleatorio ;
        numAleatorio = rand.nextInt(20);
            
        if(tecla == "c") {
            
            if(numAleatorio > numEscolhido) {
                System.out.println("ACERTOU!!!");
                pontuacao++;
            } else {
                System.out.println("FALHOU!!!");
                game = false;
            }
            
        } else if(tecla == "b") {
            
            if(numAleatorio < numEscolhido) {
                System.out.println("ACERTOU!!!");
                pontuacao++;
            } else {
                System.out.println("FALHOU!!!");
                game = false;
            }
                
        }
            System.out.println(pontuacao);
        }
      
    }
    
}