package Exercicios;

import java.util.Scanner;

public class Exercicio15 {

    public Exercicio15() {
    
        int[]   quantPasteis = new int[5];
        int[][] ordenarQuant = new int[5][2];
        
        double media    = 0;
        
        for(int i = 0; i < 5; i++) {
            
            System.out.print("Insira a quantidade de pasteis que vendeu no dia " + (i+1) + ": ");
            quantPasteis[i] = new Scanner(System.in).nextInt();
            
            media += quantPasteis[i];
            
        }
        
        for(int i = 0; i < 5; i++) {
           
            int maior = -1,
                pos   = 0;
            
            for(int x = 0; x < 5; x++) {
                
                if(quantPasteis[x] > maior) {
                    maior = quantPasteis[x];
                    pos = x;
                }
                
            }
            
            
            
            
        }
           
        System.out.println("Média: " + (media/5));
        
        
        
    }
    
}
