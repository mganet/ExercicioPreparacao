package Exercicios;

import java.util.Scanner;

public class Exercicio10 {

    public Exercicio10() {
    
        int num1    = 0,
            result  = 0;
        
        do {
            
            if(result == 0) {
                
                System.out.print("Num: ");
                result = new Scanner(System.in).nextInt();
                if(result == 0) break;
                
            }
            
            System.out.print("Num: ");
            num1 = new Scanner(System.in).nextInt();
            
            if(num1 == 0) break;
            
            System.out.println("Operação:");
            System.out.println("+)Adição");
            System.out.println("-)Subtração");
            System.out.println("*)Multiplicação");
            System.out.println("/)Divisão");
            System.out.print("\nEscolha: ");
            
            switch(new Scanner(System.in).nextLine()) {
                case "+" :
                    result += num1;
                    break;
                case "-" :
                    result -= num1;
                    break;
                case "*" :
                    result *= num1;
                    break;
                case "/" :
                    result /= num1;
                    break;
            }
            
            System.out.println("Resultado: " + result);
            
        }while(true);
        
    }
    
}
