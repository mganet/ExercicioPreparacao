package Exercicios;

import java.util.Random;

public class Exercicio3 {

    public Exercicio3() {
        
        Random rand = new Random();
        int[] array = new int[20],
              num   = {0,0,0,0,0,0,0,0,0};
        
        for(int i = 0; i < 20; i++) {
            
            array[i] = rand.nextInt(8) + 1;
             
            switch(array[i]) {
                case 1 :
                    num[0]++;
                    break;
                case 2 :
                    num[1]++;
                    break;
                case 3 :
                    num[2]++;
                    break; 
                case 4 :
                    num[3]++;
                    break;
                case 5 :
                    num[4]++;
                    break;
                case 6 :
                    num[5]++;
                    break;
                case 7 :
                    num[6]++;
                    break;
                case 8 :
                    num[7]++;
                    break;
                case 9 :
                    num[8]++;
                    break;
            }
                       
        }
        
        for(int i = 0; i < 9; i++) {
                System.out.println(i+1 + " x " + num[i]);
            }
        
    }
    
    
}
